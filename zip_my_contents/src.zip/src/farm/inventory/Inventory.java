package farm.inventory;

import farm.inventory.product.data.Barcode;
import farm.inventory.product.data.Quality;

public abstract class Inventory{
    public void addProduct(Barcode bar, Quality qly){

    }
}