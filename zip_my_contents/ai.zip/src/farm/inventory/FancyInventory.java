package farm.inventory;

public class FancyInventory {
}
